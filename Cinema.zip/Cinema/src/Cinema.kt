data class Cinema(
    var moviesEnter: MutableList<Movie>, var sessionsEnter: MutableList<Session>,
    var ticketEnter: MutableList<Ticket>
) {
    var movies: MutableList<Movie> = moviesEnter
    var sessions: MutableList<Session> = sessionsEnter
    var tickets: MutableList<Ticket> = ticketEnter

}
