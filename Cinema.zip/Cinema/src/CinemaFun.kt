import java.time.LocalDateTime

interface CinemaFunctions {
    fun addMovie(movie: String)
    fun removeMovie(movie: String)
    fun addSession(session: Session)
    fun removeSession(session: Session)
    fun sellTicket(movie: String?, time: LocalDateTime, row: Int, seat: Int)
    fun returnTicket(ticket: Ticket)
    fun getAvailableSeats(session: Session)
    fun getOccupiedSeats(session: Session)
    fun isSeatOccupied(session: Session, row: Int, seat: Int): Boolean
    fun CheckTicket(ticket: Ticket)
}

class CinemaFunctionsDo(private val cinema: Cinema) : CinemaFunctions {
    override fun CheckTicket(ticket: Ticket) {
        ticket.checked = true
    }

    override fun addMovie(movie: String) {
        val mov = Movie(movie)
        cinema.movies.add(mov)
    }

    override fun removeMovie(movie: String) {
        val mov = Movie(movie)
        cinema.movies.remove(mov)
    }

    override fun addSession(session: Session) {
        cinema.sessions.add(session)
    }

    override fun removeSession(session: Session) {
        cinema.sessions.remove(session)
    }

    override fun sellTicket(movie_: String?, time_: LocalDateTime, row: Int, seat: Int) {
        val session = cinema.sessions.find { it.movie == movie_ && it.time == time_ }
        if (session != null) {
            if (!isSeatOccupied(session, row, seat)) {
                session.seats[row][seat] = false
                cinema.tickets.add(Ticket(session, row, seat))
                println("Билет на фильм '${movie_}' на сеансе ${session.time} успешно продан.")
            } else {
                println("Место занято. Выберите другое место.")
            }
        } else {
            println("Такого сеанса не существует.")
        }

    }

    override fun returnTicket(ticket: Ticket) {
        val session = ticket.session
        val movie = session.movie
        session.seats[ticket.row][ticket.seat] = true
        cinema.tickets.remove(ticket)
        println("Билет на фильм '${movie}' на сеансе ${session.time} успешно возвращен.")
    }

    override fun getAvailableSeats(session: Session) {
        val freeSeats = mutableListOf<Pair<Int, Int>>()
        for (i in session.seats.indices) {
            for (j in session.seats[i].indices) {
                if (session.seats[i][j]) {
                    freeSeats.add(Pair(i, j))
                }
            }
        }
        println("Свободные места на сеансе ${session.time}:")
        for (seat in freeSeats) {
            println("Ряд ${seat.first + 1}, Место ${seat.second + 1}")
        }
    }

    override fun getOccupiedSeats(session: Session) {
        val occupiedSeats = mutableListOf<Pair<Int, Int>>()
        for (i in session.seats.indices) {
            for (j in session.seats[i].indices) {
                if (!session.seats[i][j]) {
                    occupiedSeats.add(Pair(i, j))
                }
            }
        }
        println("Занятые места на сеансе ${session.time}:")
        for (seat in occupiedSeats) {
            println("Ряд ${seat.first + 1}, Место ${seat.second + 1}")
        }
    }

    override fun isSeatOccupied(session: Session, row: Int, seat: Int): Boolean {
        return !session.seats[row][seat]
    }

}
