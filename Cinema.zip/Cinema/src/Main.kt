fun main() {
    val cinema = Cinema(mutableListOf(), mutableListOf(), mutableListOf())
    val start = DoWork()
    start.LetsDoit(cinema)
}




