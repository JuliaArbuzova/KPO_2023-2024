import java.io.File
import java.time.LocalDateTime

interface Save {
    fun saveToCsv(cinema: Cinema)
    //fun loadFromCsv(cinema: Cinema)
}

class Saving : Save {
    override fun saveToCsv(cinema: Cinema) {
        File("movies.csv").printWriter().use { out ->
            cinema.movies.forEach { out.println(it.title) }
        }

        File("sessions.csv").printWriter().use { out ->
            cinema.sessions.forEach { out.println("${it.movie},${it.time}") }
        }

        File("tickets.csv").printWriter().use { out ->
            cinema.tickets.forEach { out.println("${it.session.movie},${it.row},${it.seat},${it.checked}") }
        }
    }

    /*override fun loadFromCsv(cinema: Cinema) {
        cinema.movies = File("movies.csv").readLines().map { Movie(it) }.toMutableList()
        cinema.sessions = File("sessions.csv").readLines().map { line ->
            val (movieTitle, startTime) = line.split(',')
            Session(movieTitle, LocalDateTime.parse(startTime))
        }.toMutableList()
        cinema.tickets = File("tickets.csv").readLines().map { line ->
            val (movieTitle: String, row: String, seat: String, checked: String) = line.split(',')
            val session =
                cinema.sessions.find { it.movie == movieTitle } ?: throw IllegalStateException("Session not found")
            Ticket(session, row.toInt(), seat.toInt(), checked.toBoolean())
        }.toMutableList()
    }*/
}
