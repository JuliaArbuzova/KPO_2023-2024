import java.time.LocalDateTime

data class Session(
    val movie: String,
    val time: LocalDateTime,
    val seats: Array<Array<Boolean>> = Array(40) { Array(40) { true } }
)
