data class Ticket(
    val session: Session,
    val row: Int,
    val seat: Int,
    var checked: Boolean = false
)
