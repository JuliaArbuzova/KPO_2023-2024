import java.time.LocalDateTime
import java.time.format.DateTimeParseException

interface Work {
    fun LetsDoit(cinema: Cinema)
}

class DoWork : Work {
    override fun LetsDoit(cinema: Cinema) {
        val cinemafun = CinemaFunctionsDo(cinema)
        val cinema_print = Saving()
        var option: Int
        var ex = true
        do {
            println("Выберите и введите номер инструкции, которую хотите совершить")
            println("1. Sell ticket")
            println("2. Return ticket")
            println("3. Display available seats")
            println("4. Mark visitor check-in")
            println("5. Update movie")
            println("6. Update session")
            println("7. Display occupied seats")
            println("0. Exit")

            option = readLine()?.toIntOrNull() ?: continue

            when (option) {
                1 -> {
                    println("Введите дату и время (в формате yyyy-MM-ddTHH:mm):")
                    val input = readLine()
                    var dateTime: LocalDateTime
                    try {
                        dateTime = LocalDateTime.parse(input)
                    } catch (e: DateTimeParseException) {
                        println("Неверно введена дата")
                        continue
                    }
                    val currentDateTime = LocalDateTime.now()
                    println("Введите название фильма:")
                    val movieEnter = readLine()
                    println("Введите ряд:")
                    val rowEnter = readLine()?.toInt()
                    println("Введите место:")
                    val seatEnter = readLine()?.toInt()
                    if (dateTime.isAfter(currentDateTime)) {
                        if (rowEnter != null && rowEnter <= 40 && rowEnter >= 1) {
                            if (seatEnter != null && seatEnter <= 40 && seatEnter >= 1) {
                                cinemafun.sellTicket(movieEnter, dateTime, rowEnter, seatEnter)
                            } else {
                                println("Неверно введено место")
                            }
                        } else {
                            println("Неверно введен ряд")
                        }
                    } else {
                        println("Введенное значение даты меньше или равно текущему времени")
                    }
                }

                2 -> {
                    println("Введите дату и время (в формате (yyyy-MM-dd)T(HH:mm)):")
                    val input = readLine()
                    // Преобразование введенной строки в объект LocalDateTime
                    var dateTime: LocalDateTime
                    try {
                        dateTime = LocalDateTime.parse(input)
                    } catch (e: DateTimeParseException) {
                        println("Неверно введена дата")
                        continue
                    }
                    val currentDateTime = LocalDateTime.now()
                    println("Введите название фильма:")
                    val movieEnter = readLine()
                    println("Введите ряд:")
                    val rowEnter = readLine()?.toInt()
                    println("Введите место:")
                    val seatEnter = readLine()?.toInt()
                    if (dateTime.isAfter(currentDateTime)) {
                        if (rowEnter != null && rowEnter <= 40 && rowEnter >= 1) {
                            if (seatEnter != null && seatEnter <= 40 && seatEnter >= 1) {

                                val session_ = cinema.sessions.find { it.movie == movieEnter && it.time == dateTime }
                                if (session_ != null) {
                                    val ticket = cinema.tickets.find {
                                        it.session == session_ && it.row == rowEnter && it.seat == seatEnter
                                    }
                                    if (ticket != null) {
                                        cinemafun.returnTicket(ticket)
                                    } else {
                                        println("Неверно введены данные")
                                    }
                                } else {
                                    println("Неверно введены данные")
                                }

                            } else {
                                println("Неверно введено место")
                            }
                        } else {
                            println("Неверно введен ряд")
                        }
                    } else {
                        println("Введенное значение даты меньше или равно текущему времени")
                    }

                }

                3 -> {
                    println("Введите дату и время (в формате (yyyy-MM-dd)T(HH:mm)):")
                    val input = readLine()
                    // Преобразование введенной строки в объект LocalDateTime
                    var dateTime: LocalDateTime
                    try {
                        dateTime = LocalDateTime.parse(input)
                    } catch (e: DateTimeParseException) {
                        println("Неверно введена дата")
                        continue
                    }
                    println("Введите название фильма:")
                    val movieEnter = readLine()
                    val session_ = cinema.sessions.find { it.movie == movieEnter && it.time == dateTime }
                    if (session_ != null) {
                        cinemafun.getAvailableSeats(session_)
                    } else {
                        println("Неверно введены данные")
                    }
                }

                4 -> {//4. Mark visitor check-in
                    println("Введите дату и время (в формате (yyyy-MM-dd)T(HH:mm)):")
                    val input = readLine()
                    // Преобразование введенной строки в объект LocalDateTime
                    var dateTime: LocalDateTime
                    try {
                        dateTime = LocalDateTime.parse(input)
                    } catch (e: DateTimeParseException) {
                        println("Неверно введена дата")
                        continue
                    }
                    println("Введите название фильма:")
                    val movie_enter = readLine()
                    println("Введите ряд:")
                    val row_enter = readLine()?.toInt()
                    println("Введите место:")
                    val seat_enter = readLine()?.toInt()
                    if (row_enter != null && row_enter <= 40 && row_enter >= 1) {
                        if (seat_enter != null && seat_enter <= 40 && seat_enter >= 1) {

                            val session_ = cinema.sessions.find { it.movie == movie_enter && it.time == dateTime }
                            if (session_ != null) {
                                val ticket = cinema.tickets.find {
                                    it.session == session_ && it.row == row_enter && it.seat == seat_enter
                                }
                                if (ticket != null) {
                                    cinemafun.CheckTicket(ticket)
                                } else {
                                    println("Неверно введены данные")
                                }
                            } else {
                                println("Неверно введены данные о сеансе")
                            }

                        } else {
                            println("Неверно введено место")
                        }
                    } else {
                        println("Неверно введен ряд")
                    }

                }

                5 -> {// Update movie
                    var opt: Int
                    println("1. Add movie")
                    println("2. Delete movie")
                    opt = readLine()?.toIntOrNull() ?: continue

                    when (opt) {
                        1 -> {
                            println("The name of the film")
                            val movie_enter = readLine()
                            if (movie_enter != null) {
                                cinemafun.addMovie(movie_enter)
                                cinema_print.saveToCsv(cinema)
                            } else {
                                println("Неверно введены данные")
                            }
                        }

                        2 -> {
                            println("The name of the film")
                            val movie_enter = readLine()
                            if (movie_enter != null) {
                                cinemafun.removeMovie(movie_enter)
                                cinema_print.saveToCsv(cinema)
                            } else {
                                println("Неверно введены данные")
                            }
                        }
                    }

                }

                6 -> {//Update session //добавить что можно и удалить кино
                    var opt: Int
                    println("1. Add session")
                    println("2. Delete session")
                    opt = readLine()?.toIntOrNull() ?: continue

                    when (opt) {
                        1 -> {
                            println("The name of the film")
                            val movie_enter = readLine().toString()
                            println("Введите дату и время (в формате (yyyy-MM-dd)T(HH:mm)):")
                            val input = readLine()
                            var dateTime: LocalDateTime
                            try {
                                dateTime = LocalDateTime.parse(input)
                            } catch (e: DateTimeParseException) {
                                println("Неверно введена дата")
                                continue
                            }
                            val sess = Session(movie_enter, dateTime)
                            cinemafun.addSession(sess)
                            cinema_print.saveToCsv(cinema)
                        }

                        2 -> {
                            println("The name of the film")
                            val movie_enter = readLine().toString()
                            println("Введите дату и время (в формате (yyyy-MM-dd)T(HH:mm)):")
                            val input = readLine()
                            var dateTime: LocalDateTime
                            try {
                                dateTime = LocalDateTime.parse(input)
                            } catch (e: DateTimeParseException) {
                                println("Неверно введена дата")
                                continue
                            }
                            val session_ = cinema.sessions.find { it.movie == movie_enter && it.time == dateTime }
                            if (session_ != null) {
                                cinemafun.removeSession(session_)
                                cinema_print.saveToCsv(cinema)
                            } else {
                                println("Неверно введены данные")
                            }
                        }
                    }
                }

                7 -> {
                    println("Введите дату и время (в формате (yyyy-MM-dd)T(HH:mm)):")
                    val input = readLine()
                    // Преобразование введенной строки в объект LocalDateTime
                    var dateTime: LocalDateTime
                    try {
                        dateTime = LocalDateTime.parse(input)
                    } catch (e: DateTimeParseException) {
                        println("Неверно введена дата")
                        continue
                    }
                    println("Введите название фильма:")
                    val movieEnter = readLine()
                    val session_ = cinema.sessions.find { it.movie == movieEnter && it.time == dateTime }
                    if (session_ != null) {
                        cinemafun.getOccupiedSeats(session_)
                    } else {
                        println("Неверно введены данные")
                    }
                }

                0 -> {//Exit
                    ex = false
                    println("Thank you for choosing us")
                }
            }
        } while (ex)
    }

}